from django import template

register = template.Library()


# for currency symbol ₹...
@register.filter(name='currency')
def currency(number):
    return "₹" + str(number)


# for multiply by price and quantity for your orders.html...
@register.filter(name='multiply')
def multiply(number, number1):
    return number * number1
