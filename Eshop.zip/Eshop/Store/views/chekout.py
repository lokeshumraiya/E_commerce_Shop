from django.shortcuts import *
from django.http import *
from Store.models.customer import Customer
from Store.models.product import Product
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
from Store.models.orders import Order


# place your order where you want......
class Checkout_Placeorder(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        print(address, phone, customer, cart, products)

        for product in products:
            order = Order(customer=Customer(id=customer),
                          product=product,
                          price=product.price,
                          address=address,
                          phone=phone,
                          quantity=cart.get(str(product.id)))
            request.session['cart'] = {}
            print(order.placeorder())
        return redirect('cart')
