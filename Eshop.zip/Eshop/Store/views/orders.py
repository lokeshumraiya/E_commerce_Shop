from django.shortcuts import *
from django.http import *
from Store.models.customer import Customer
from Store.models.product import Product
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
from Store.models.orders import Order
from Store.middleware.auth import auth_middleware


# place your order where you want......

class Your_Order(View):

    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_order_by_customr(customer)
        print(orders)
        return render(request, 'orders.html', {'orders': orders})
