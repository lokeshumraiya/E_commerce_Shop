from django.contrib import admin
from django.urls import path
from .views.home import Index
from .views.signup import Signup
from .views.login import Login, logout
from .views.cart import Cart
from .views.chekout import Checkout_Placeorder
from .views.orders import Your_Order
from .middleware.auth import auth_middleware

# For CBV........
urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('signup/', Signup.as_view(), name='signup'),
    path('login/', Login.as_view(), name='login'),
    path('logout/', logout, name='logout'),
    path('cart/', auth_middleware(Cart.as_view()), name='cart'),
    path('placeorder/', Checkout_Placeorder.as_view(), name='placeorder'),
    path('yourorder/', auth_middleware(Your_Order.as_view()), name='yourorder'),

]

# For FBV........

# from .views import index, signup
#
# urlpatterns = [
#     path('', index, name='homepage'),
#     path('signup', signup, name='signup'),
#
# ]
